"""Start the isolated requirement-4 HTTP demonstration on this Windows computer."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import venv


ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--interactive',action='store_true',help='Pause before mutation and before shutdown for Swagger/manual HTTP inspection')
    parser.add_argument('--build-images',action='store_true',help='Build/pull missing images explicitly')
    args=parser.parse_args()
    docker=shutil.which('docker')
    if not docker:
        candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs/DockerDesktop/resources/bin/docker.exe',
                    Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Docker/Docker/resources/bin/docker.exe']
        docker=next((str(p) for p in candidates if p.is_file()),None)
    if not docker:
        raise RuntimeError('Docker Desktop was not found. Install/open Docker Desktop first.')
    env={**os.environ,'PATH':str(Path(docker).parent)+os.pathsep+os.environ.get('PATH',''),
         'PYTHONUNBUFFERED':'1','COMPOSE_ANSI':'never','COMPOSE_PROGRESS':'plain'}
    def engine_ready():
        try:
            return subprocess.run([docker,'version','--format','{{.Server.Version}}'],env=env,
                       capture_output=True,text=True,timeout=12).returncode==0
        except subprocess.TimeoutExpired:
            return False
    if not engine_ready():
        print('Starting Docker Desktop...',flush=True)
        subprocess.run([docker,'desktop','start','--detach'],env=env,check=True,timeout=30)
        deadline=time.monotonic()+100
        while not engine_ready():
            if time.monotonic()>deadline:
                raise RuntimeError('Docker Linux Engine is not ready. Wait for Docker Desktop to finish starting, then run again.')
            time.sleep(2)
    inspect=subprocess.run([docker,'image','inspect','restestbench-codex-fastapi-backend:4decc1e','postgres:17'],
                           env=env,capture_output=True,text=True,timeout=20)
    if inspect.returncode:
        if not args.build_images:
            raise RuntimeError('A Docker image is missing. Run the repository launcher with --build-images to prepare images, or use the original prepared images.')
        for image in ('postgres:17','restestbench-codex-fastapi-backend:4decc1e'):
            present=subprocess.run([docker,'image','inspect',image],env=env,capture_output=True,text=True)
            if present.returncode:
                cmd=([docker,'pull',image] if image=='postgres:17' else
                     [docker,'build','-t',image,str(ROOT/'work/RESTestBench/services/fastapi/original/backend')])
                subprocess.run(cmd,env=env,check=True)

    python=ROOT/'.venv/Scripts/python.exe'
    if not python.is_file():
        print('Preparing a separate Python environment for this demo...',flush=True)
        venv.EnvBuilder(with_pip=True).create(ROOT/'.venv')
    check=subprocess.run([str(python),'-c','import requests; assert requests.__version__ == "2.34.2"'],
                         env=env,capture_output=True,text=True)
    if check.returncode:
        print('Installing Requests 2.34.2 from PyPI (first setup only)...',flush=True)
        subprocess.run([str(python),'-m','pip','install','--disable-pip-version-check','--index-url',
                        'https://pypi.org/simple','-r',str(ROOT/'requirements-http.txt')],env=env,check=True,timeout=180)
    print('\nReal HTTP demo: two accounts -> item owned by first account -> second account reads it.',flush=True)
    print('Original expectation: HTTP 400, detail=Not enough permissions.',flush=True)
    print('Injected mutant: HTTP 400, detail=Item not found. No LLM generation is performed.\n',flush=True)
    cmd=[str(python),str(ROOT/'http_demo.py'),'live']
    if args.interactive:
        cmd.append('--interactive')
    return subprocess.run(cmd,cwd=ROOT,env=env).returncode


if __name__=='__main__':
    try:
        sys.exit(main())
    except (OSError,RuntimeError,subprocess.SubprocessError) as e:
        print(f'ERROR: {e}',file=sys.stderr)
        sys.exit(1)
