"""
Benchmark Error Logger

Writes structured JSONL log entries during a benchmark run so you can
inspect problems after a long multi-model run without losing them in
the terminal scroll-back.

Log file: <output_dir>/benchmark_errors.jsonl
Format  : one JSON object per line (JSONL), human-readable

Each entry contains:
  timestamp    – ISO-8601 wall-clock time
  level        – "INFO" | "WARN" | "ERROR"
  event        – short machine-readable key (see EVENT_* constants below)
  model        – model ID (e.g. "gpt-5-mini")
  approach     – "single-step" | "refinement"
  output_folder– relative path to this run's output directory
  service      – current service name (set via set_context)
  requirement_id – current requirement number (set via set_context)
  message      – human-readable description
  details      – optional dict with extra data

Usage (automatic – wired up by run_mutation_benchmark.py):
    # The benchmark creates the logger and attaches it to the tool:
    logger = BenchmarkLogger(log_file=output_dir / "benchmark_errors.jsonl",
                             model="gpt-5-mini", approach="single-step",
                             output_folder="gpt5mini_single-step_20260220_103000")
    tool.logger = logger
    # Then the tool and generator call logger.warn/error automatically.

    # Before each service / requirement the benchmark updates context:
    logger.set_context(service="nestjs-realworld", requirement_id=5)

Reading the log after a run:
    import json
    with open("output/.../benchmark_errors.jsonl") as f:
        entries = [json.loads(line) for line in f if line.strip()]
    errors = [e for e in entries if e["level"] == "ERROR"]
"""

import json
from datetime import datetime
from pathlib import Path

# ── event name constants ──────────────────────────────────────────────────────

# LLM call events (tools)
EVENT_RATE_LIMIT         = "rate_limit_hit"          # Rate limit, retrying
EVENT_REFUSAL            = "content_filter_refusal"   # Content filter blocked
EVENT_EMPTY_RESPONSE     = "empty_response"           # LLM returned empty text
EVENT_GENERATION_FAILED  = "generation_failed"        # All retries exhausted
EVENT_EMPTY_CODE         = "empty_code_extracted"     # Code extraction failed

# Test quality events (generator)
EVENT_INVALID_SYNTAX     = "invalid_syntax"           # Generated test has bad syntax
EVENT_TOOL_EXCEPTION     = "tool_exception"           # Unhandled exception in tool

# Service / infrastructure events (benchmark orchestrator)
EVENT_SERVICE_START_FAIL = "service_start_failed"     # Service wouldn't start
EVENT_SERVICE_UNHEALTHY  = "service_unhealthy"        # Service not reachable
EVENT_TOOL_FAILED        = "tool_failed"              # Entire tool run crashed

# Lifecycle events
EVENT_RUN_START          = "run_start"                # Run begins
EVENT_RUN_COMPLETE       = "run_complete"             # Run finishes


class BenchmarkLogger:
    """
    Lightweight JSONL event logger attached to a benchmark tool run.

    One instance is created per tool (model + approach combination).
    It writes to a .jsonl file in the tool's output directory.

    The benchmark orchestrator (run_mutation_benchmark.py) creates the
    logger and assigns it to the tool: ``tool.logger = logger``.
    Tools and the generator then log via ``getattr(self, 'logger', None)``.
    """

    def __init__(self, log_file: Path, model: str, approach: str, output_folder: str):
        """
        Args:
            log_file:      Absolute path to the .jsonl log file.
            model:         Model ID string (e.g. "gpt-5-mini").
            approach:      Approach name (e.g. "single-step", "refinement").
            output_folder: Human-readable run folder name written into every entry.
        """
        self.log_file = Path(log_file)
        self.model = model
        self.approach = approach
        self.output_folder = output_folder

        # Mutable context updated per service + requirement
        self._context: dict = {}

        # Ensure parent directory exists on creation
        self.log_file.parent.mkdir(parents=True, exist_ok=True)

    # ── context management ────────────────────────────────────────────────────

    def set_context(self, **kwargs):
        """
        Update the current logging context.

        Common keys: service="nestjs-realworld", requirement_id=5
        These are merged into every subsequent log entry until overwritten.
        """
        self._context.update(kwargs)

    def clear_context(self):
        """Remove all current context (call between services if needed)."""
        self._context.clear()

    # ── write helpers ─────────────────────────────────────────────────────────

    def _write(self, level: str, event: str, message: str, **details):
        """Build and append one JSONL entry."""
        entry = {
            "timestamp": datetime.now().isoformat(timespec="milliseconds"),
            "level": level,
            "event": event,
            "model": self.model,
            "approach": self.approach,
            "output_folder": self.output_folder,
        }
        # Merge current context (service, requirement_id, …)
        entry.update(self._context)
        entry["message"] = message
        if details:
            entry["details"] = details

        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def info(self, event: str, message: str, **details):
        """Log an informational entry (run lifecycle, summaries)."""
        self._write("INFO", event, message, **details)

    def warn(self, event: str, message: str, **details):
        """Log a warning (retried but continued, degraded output)."""
        self._write("WARN", event, message, **details)

    def error(self, event: str, message: str, **details):
        """Log an error (requirement skipped or failed)."""
        self._write("ERROR", event, message, **details)
